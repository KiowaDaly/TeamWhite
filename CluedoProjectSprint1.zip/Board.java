/** Author Seán Letmon
 * 
 * Software Project - Cluedo Game
 * 
 * Team plum
 * 
 * Board implementation
 **/

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;


// dining room co-ordinates (104,284)
// hall co-ordinates (293,535)
//study co-ordinates (497,520)
//Libary co-ordinates (528,373)
//Billiard room co-ordinates (543,228)
//conservetory co-ordinates (481,57)
//Ball room co-ordinates (292,68)
//Kitchen co-ordinates (93,48)
//Lounge co-ordinates (93,535)


//Mrs. Scarlet start point co-ordinates (202,573)
//Professer Plum start point co-ordinates (573,457)
//Mrs. Peacock start point co-ordinates (571,157)
//Mr. Green start point co-ordinates(362,21)
//Mrs. White start point co-ordinates (248, 21)
//Colonel Mustard start point co-ordinates (41,412)



public class Board extends JPanel implements ActionListener {
	
	private static final long serialVersionUID = 1L; 
	
	private Image CluedoBoard;
	private Icons player1,player2,player3,player4,player5,player6;
	private WeaponIcon candlestick,Leadpipe,dagger,rope,gun,wrench;
	private final int DELAY = 200;
	private Timer timer;


	public Board() {

		initiateBoard();
		initiateBoard2();
	}

	private void initiateBoard() {

		loadImage();

		int w = CluedoBoard.getWidth(this); //sets w to original width of the image
		int h =  CluedoBoard.getHeight(this);//sets h to original height of the image
		setPreferredSize(new Dimension(w, h));         //Creates cluedo board
	}

	private void initiateBoard2() {

		addKeyListener(new ButtonAdapter()); //allows for keyboard input
		setFocusable(true);
		//setBackground(Color.BLACK);

		player1 = new Icons();
		player2= new Icons(); 
		player3= new Icons();
		player4= new Icons();                //creation of players
		player5= new Icons();
		player6= new Icons();

		candlestick = new WeaponIcon();
		Leadpipe = new WeaponIcon();
		gun = new WeaponIcon();
		rope = new WeaponIcon();          //creation of weapons
		dagger = new WeaponIcon();
		wrench = new WeaponIcon();


		timer = new Timer(DELAY, this);
		timer.start();        //delay for keyboard input
	}
	private void loadImage() {

		ImageIcon ii = new ImageIcon("CluedoBoard.jpg");
		CluedoBoard = ii.getImage();       
	}


	/* Drawing of the board*/
	public void paintComponent(Graphics g) {
		//super.paintComponent(g);
		g.drawImage(CluedoBoard, 0, 0, null); 
		PlayerDrawing(g);                            
		WeaponDrawing(g);
	}



	private void PlayerDrawing(Graphics g) {

		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(player1.getImage(), player1.getX(), player1.getY(), this);

		player2.setX(573);
		player2.setY(457);
		g2d.drawImage(player2.getImage(), player2.getX(), player2.getY(), this);

		player3.setX(571);
		player3.setY(157);
		g2d.drawImage(player3.getImage(), player3.getX(), player3.getY(), this);

		player4.setX(362);
		player4.setY(21);
		g2d.drawImage(player4.getImage(), player4.getX(), player4.getY(), this);

		player5.setX(248);
		player5.setY(21);
		g2d.drawImage(player5.getImage(), player5.getX(), player5.getY(), this);

		player6.setX(41);
		player6.setY(412);
		g2d.drawImage(player6.getImage(), player6.getX(), player6.getY(), this);
	}


	private void WeaponDrawing(Graphics g) {

		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(candlestick.getImage(),candlestick.getX(), candlestick.getY(), this);

		Leadpipe.setX(104);
		Leadpipe.setY(284);

		Leadpipe.setImage("leadpipe.png");
		g2d.drawImage(Leadpipe.getImage(), Leadpipe.getX(), Leadpipe.getY(), this);

		dagger.setX(293);
		dagger.setY(535);
		dagger.setImage("dagger.png");
		g2d.drawImage(dagger.getImage(), dagger.getX(), dagger.getY(), this);

		rope.setX(93);
		rope.setY(535);
		rope.setImage("rope.png");
		g2d.drawImage(rope.getImage(), rope.getX(), rope.getY(), this);

		gun.setX(528);
		gun.setY(373);
		gun.setImage("gun.png");
		g2d.drawImage(gun.getImage(), gun.getX(), gun.getY(), this);

		wrench.setX(481);
		wrench.setY(57);
		wrench.setImage("wrench.png");
		g2d.drawImage(wrench.getImage(), wrench.getX(), wrench.getY(), this);
	}




	/*Reads button inputs*/
	@Override
	public void actionPerformed(ActionEvent e) {
		candlestick.move();
		player1.move();

		repaint();

	}

	private class ButtonAdapter extends KeyAdapter {

		@Override
		public void keyReleased(KeyEvent e) {
			candlestick.keyReleased(e);
			player1.keyReleased(e);


		}

		@Override
		public void keyPressed(KeyEvent e) {
			candlestick.keyPressed(e);
			player1.keyPressed(e);

		}
	}
}


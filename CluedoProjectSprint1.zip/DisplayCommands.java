/** Author Leona McNulty
 * 
 * Software Project - Cluedo Game
 * 
 * TeamPlum
 * 
 * Command Panel
 **/

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;

public class DisplayCommands extends JPanel {
	
	private static final long serialVersionUID = 1L;
	
	private static final int COMMAND_AREA_HEIGHT = 50;
	private static final int COMMAND_AREA_WIDTH = 40;
	private static final int FONT_SIZE = 12;
	
	JTextArea displayPanel = new JTextArea(COMMAND_AREA_HEIGHT, COMMAND_AREA_WIDTH);
	JScrollPane scrollBar = new JScrollPane(displayPanel);
	JTextField commandField = new JTextField();
	
	DisplayCommands	 () {
		
		super();

		//DISPLAY PANEL
		displayPanel.setEditable(false);
		setLayout(new BorderLayout());
		displayPanel.setFont(new Font("SansSerif", Font.PLAIN, FONT_SIZE));
		displayPanel.setLineWrap(true);
		displayPanel.setWrapStyleWord(true);
	
		//SCROLL PANE 
		scrollBar.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		setLayout(new BorderLayout());
		add(scrollBar, BorderLayout.CENTER);
		add(commandField, BorderLayout.SOUTH);
		
		 TextFieldHandler handler = new TextFieldHandler();
		 commandField.addActionListener(handler);
		
		return;

	}
	
	private class TextFieldHandler implements ActionListener{

	    public void actionPerformed(ActionEvent event)
	    {     
	        String line = commandField.getText();
	        displayPanel.append(line + "\n"); 
	    }
	}


}



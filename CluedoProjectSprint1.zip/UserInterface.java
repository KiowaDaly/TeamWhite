/** Author Seán Letmon & Leona McNulty
 * 
 * Software Project - Cluedo Game
 * 
 * TeamPlum
 * 
 * Frame creation
 **/
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.awt.BorderLayout;

public class UserInterface extends JFrame {
    
    private static final long serialVersionUID = 1L;
    
//     private static UserInput commandPanel = new UserInput(); 
     private static DisplayCommands infoPanel = new DisplayCommands();

    public UserInterface() {

        initiateUI();
    }

    private void initiateUI() {

        add(new Board());

        pack();
    }

    public static void main(String[] args) {

    			UserInterface frame = new UserInterface();
    			frame.setTitle("Cluedo Project"); 
    		    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    		    frame.setLocationRelativeTo(null); //places frame in middle of the screen
    		       
    		    frame.setResizable(false);
    	        frame.setSize(1100, 720); 
        
                //INFO PANEL
    	    	frame.add(infoPanel, BorderLayout.LINE_END);
        
                frame.setVisible(true);
        
         
        
    }
}

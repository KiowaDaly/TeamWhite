/** Author Se�n Letmon
 * 
 * Software Project - Cluedo Game
 * 
 * Team plum
 * 
 * Weapon creation and movement
 **/

import java.awt.Image;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;

public class WeaponIcon {

	private int dx;
	private int dy;
	private int x;
	private int y;
	private Image image;

	public WeaponIcon() {

		initiateWeapon();
	}

	private void initiateWeapon() {

		ImageIcon ii = new ImageIcon("candleStick.png");
		image = ii.getImage();
		x = 40;
		y = 60; 

	}


	public void move() {
		x += dx;
		y += dy;
	}



	public int getX() {
		return x;
	}

	public  void setX(int x) {

		this.x=x;

	}

	public int getY() {
		return y;
	}


	public  void setY(int y) {

		this.y=y;

	}


	public void setImage(String s) {
		ImageIcon ii = new ImageIcon(s);
		this.image = ii.getImage();
	}

	public Image getImage() {
		return image;
	}

	public void keyPressed(KeyEvent e) {

		int key = e.getKeyCode();

		if (key == KeyEvent.VK_A) {
			dx = -23;                     //Press A to move the weapon left
		}

		if (key == KeyEvent.VK_D) {
			dx = 23;                      //Press D to move the weapon right
		}

		if (key == KeyEvent.VK_W) {
			dy = -23;                   //Press w to move the weapon up
		}

		if (key == KeyEvent.VK_S) {          //Press S to move the weapon right
			dy = 23;
		}
	}

	public void keyReleased(KeyEvent e) {

		int key = e.getKeyCode();

		if (key == KeyEvent.VK_A) {
			dx = 0;
		}

		if (key == KeyEvent.VK_D) {
			dx = 0;
		}

		if (key == KeyEvent.VK_W) {
			dy = 0;
		}

		if (key == KeyEvent.VK_S) {
			dy = 0;
		}
	}
}
